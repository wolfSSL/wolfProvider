/* sm2.h
 *
 * Copyright (C) 2006-2026 wolfSSL Inc.  All rights reserved.
 *
 * This file is part of wolfSSL.
 *
 * Contact licensing@wolfssl.com with any questions or comments.
 *
 * https://www.wolfssl.com
 */

#ifdef WOLFSSL_SM2

#error "See https://github.com/wolfSSL/wolfsm for implementation of this file"

#endif

